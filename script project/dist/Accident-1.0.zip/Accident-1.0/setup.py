# -*- coding: utf-8 -*-
"""
Created on Thu Jun 16 00:25:10 2016

@author: dltkd
"""

from distutils.core import setup

setup(name = 'Accident',
      version = '1.0',
      py_modules = ['launcher'],
)